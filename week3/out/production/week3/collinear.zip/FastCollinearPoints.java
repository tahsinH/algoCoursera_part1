/**
 * Created by thassan on 9/20/18.
 */

public class FastCollinearPoints {
    /**
     * finds all line segments containing 4 or more points
     *
     * @param points
     */
    public FastCollinearPoints(Point[] points) {

    }

    /**
     * the number of line segments
     *
     * @return
     */
    public int numberOfSegments() {
        throw new UnsupportedOperationException();
    }

    public LineSegment[] segments() {
        throw new UnsupportedOperationException();

    }
}
